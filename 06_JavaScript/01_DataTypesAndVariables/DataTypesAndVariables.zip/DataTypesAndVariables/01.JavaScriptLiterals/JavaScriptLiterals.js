var integerNumber = 7;
var floatNumber = 1.2;
var stringVariable = 'Some string';
var booleanVariable = true;
var nanVariable = NaN;
var undefinedVariable = undefined;
var nullVariable = null;
var arrayVariable = [1, 2, 3];
var objectVariable = {'firstName': 'Pesho', 'age': 20};

console.log(integerNumber);
console.log(floatNumber);
console.log(stringVariable);
console.log(booleanVariable);
console.log(nanVariable);
console.log(undefinedVariable);
console.log(nullVariable);
console.log('Array[]: ' + arrayVariable.join(','));
console.log('Object\'s first name: ' + objectVariable.firstName + ', Object\'s age: ' + objectVariable.age);