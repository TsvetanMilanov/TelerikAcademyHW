var nullVariable = null;
var undefinedVariable = undefined;

console.log(typeof(nullVariable));
console.log(typeof(undefinedVariable));