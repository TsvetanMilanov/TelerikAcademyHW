var integerNumber = 7;
var floatNumber = 1.2;
var stringVariable = 'Some string';
var booleanVariable = true;
var nanVariable = NaN;
var arrayVariable = [1, 2, 3];
var objectVariable = {'firstName': 'Pesho', 'age': 20};

console.log(typeof(integerNumber));
console.log(typeof(floatNumber));
console.log(typeof(stringVariable));
console.log(typeof(booleanVariable));
console.log(typeof(nanVariable));
console.log(typeof(arrayVariable));
console.log(typeof(objectVariable));