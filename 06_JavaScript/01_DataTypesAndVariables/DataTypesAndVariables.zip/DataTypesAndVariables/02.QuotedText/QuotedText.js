var quotedText = '"How you doin\'?", Joey said.';

console.log(quotedText);