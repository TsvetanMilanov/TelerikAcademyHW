var a = 8.5;
var b = 4.3;
var h = 2.7;

var area = ((a + b) / 2) * h;

console.log(area);