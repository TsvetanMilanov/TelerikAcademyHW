var number = 9703;

if ((((number % 1000) / 100) | 0) == 7) {
    console.log(true);
} else {
    console.log(false);
}