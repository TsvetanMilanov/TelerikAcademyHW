var number = 62241;

var mask = 8;

if ((number & mask) == mask) {
    console.log(1);
}
else {
    console.log(0);
}