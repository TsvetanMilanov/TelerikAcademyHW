var width = 2.5;
var height = 3;

var area = width * height;

console.log('area of rectangle with width: ' + width + ' and height: ' + height + ' is: ' + area);