var i,
    a = new Array(20);

for (i = 0; i < 20; i += 1) {
    a[i] = i * 5;
}

console.log("a = " + a);