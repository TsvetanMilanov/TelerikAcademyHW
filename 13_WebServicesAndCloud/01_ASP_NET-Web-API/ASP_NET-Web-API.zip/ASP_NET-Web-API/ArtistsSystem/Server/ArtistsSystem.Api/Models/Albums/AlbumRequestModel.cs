﻿namespace ArtistsSystem.Api.Models.Albums
{
    public class AlbumRequestModel
    {
        public string Title { get; set; }

        public int Year { get; set; }

        public int ProducerId { get; set; }
    }
}