﻿namespace ArtistsSystem.Api.Models.Artists
{
    public class ArtistRequestModel
    {
        public string Name { get; set; }
    }
}