﻿namespace ArtistsSystem.Models
{
    public enum Genre
    {
        Trap = 0,
        Dubstep = 1,
        Hardcore = 2
    }
}
