﻿namespace StudentSystem.Common
{
    public class GlobalConstants
    {
        public const string DataServicesAssemblyName = "StudentsSystem.Services.Data";
    }
}
