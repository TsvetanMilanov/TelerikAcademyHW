﻿namespace StudentsSystem.Services.Models.Student
{
    public class StudentRequestModel
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Level { get; set; }
    }
}