﻿namespace StudentsSystem.Services.Models.Homewrok
{
    using System;

    public class HomeworkRequestModel
    {
        public string FileUrl { get; set; }

        public DateTime TimeSent { get; set; }
    }
}