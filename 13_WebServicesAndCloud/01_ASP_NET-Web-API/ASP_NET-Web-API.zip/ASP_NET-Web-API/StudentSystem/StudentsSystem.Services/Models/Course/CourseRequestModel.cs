﻿namespace StudentsSystem.Services.Models.Course
{
    using System;

    public class CourseRequestModel
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}