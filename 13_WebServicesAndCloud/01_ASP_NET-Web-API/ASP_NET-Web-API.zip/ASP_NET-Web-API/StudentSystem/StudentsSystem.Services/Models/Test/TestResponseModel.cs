﻿namespace StudentsSystem.Services.Models.Test
{
    using System;

    public class TestResponseModel
    {
        public int Id { get; set; }

        public Guid CourseId { get; set; }
    }
}