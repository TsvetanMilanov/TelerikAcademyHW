﻿namespace StudentsSystem.Services.Models.Test
{
    using System;

    public class TestRequestModel
    {
        public Guid CourseId { get; set; }
    }
}