﻿namespace InfiniteConvergentSeries
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class SeriesMain
    {
        public static void Main(string[] args)
        {

        }
    }
}
