﻿namespace GSMInformation.Enumerations
{
    public enum BatteryType
    {
        LiIon,
        NiMH,
        NiCd,
        LiPolymer
    }
}
