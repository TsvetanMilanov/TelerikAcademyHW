﻿namespace AnimalHierarchy
{
    public interface ISound
    {
        string MakeSound();
    }
}
