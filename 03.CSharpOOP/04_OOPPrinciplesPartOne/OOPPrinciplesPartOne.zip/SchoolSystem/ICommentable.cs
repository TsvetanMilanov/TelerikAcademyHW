﻿namespace SchoolSystem
{
    public interface ICommentable
    {
        string Comment { get; set; }
    }
}
