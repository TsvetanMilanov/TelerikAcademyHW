﻿namespace Bank.Customers
{
    public interface IPrintable
    {
        /// <summary>
        /// Returns the customers name.
        /// </summary>
        /// <returns></returns>
        string DisplayCustomersName();
    }
}
