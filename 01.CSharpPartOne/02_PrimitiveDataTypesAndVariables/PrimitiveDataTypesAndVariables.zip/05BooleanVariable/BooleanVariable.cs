﻿using System;

/*Problem 5. Boolean Variable

Declare a Boolean variable called isFemale and assign an appropriate value corresponding to your gender.
Print it on the console.*/

class BooleanVariable
{
    static void Main(string[] args)
    {
        bool isFemale = false;
        Console.WriteLine(isFemale);
    }
}
