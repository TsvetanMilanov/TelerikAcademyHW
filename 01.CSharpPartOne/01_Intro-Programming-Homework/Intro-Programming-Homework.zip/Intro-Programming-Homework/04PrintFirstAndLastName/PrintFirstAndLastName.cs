﻿using System;

/*Print First and Last Name

Create console application that prints your first and last name, each at a separate line.*/

class PrintFirstAndLastName
{
    static void Main(string[] args)
    {
        Console.WriteLine("Tsvetan");
        Console.WriteLine("Milanov");
    }
}
