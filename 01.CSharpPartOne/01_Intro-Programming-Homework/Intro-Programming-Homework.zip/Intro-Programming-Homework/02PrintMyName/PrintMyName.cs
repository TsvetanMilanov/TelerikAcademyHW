﻿using System;

/*Problem 5. Print Your Name

Modify the previous application to print your name.
Ensure you have named the application well (e.g. “PrintMyName”).*/

class PrintMyName
{
    static void Main(string[] args)
    {
        Console.WriteLine("Tsvetan Milanov");
    }
}
