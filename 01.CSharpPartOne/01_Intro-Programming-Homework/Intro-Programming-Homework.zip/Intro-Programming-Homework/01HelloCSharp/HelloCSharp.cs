﻿using System;

/*Problem 4. Hello World

Create, compile and run a “Hello C#” console application.
Ensure you have named the application well (e.g. “”HelloCSharp”).*/

class HelloCSharp
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello C#!");
    }
}
