﻿namespace LinkedListTask
{
    public class LinkedList<T>
    {
        public ListItem<T> FirstElement { get; set; }
    }
}
